<?php
    session_start();
    date_default_timezone_set('Europe/Warsaw');

    //dodanie komentarzów
    if (isset($_POST['komentarz']) && strlen($_POST['komentarz']) > 0) {
        require_once "connect.php";
        $conn = new mysqli($host, $db_user, $db_password, $db_name);
        if(!isset($_SESSION['nick'])) {
            header("Location: zaloguj.php"); 
            exit();
        }
        // Retrieve form data
        $comment = $_POST['komentarz'];
        $post_id = $_POST['post_id'];
        $user_id = $_SESSION['id'];
        
        // Get current date and time in the desired format
        $currentDate_comm = date('D-m-y H:i'); // Assuming your database expects datetime in this format
        
        // Insert comment into the database
        $sql_comm = "INSERT INTO comments VALUES (NULL, '$comment', '$user_id', '$post_id', '$currentDate_comm')";
        
        $conn->query($sql_comm);
    }
    
    //dodania postu
    if(isset($_POST['problem']) and strlen($_POST['problem']) > 0){
        require_once "connect.php";
        $conn = new mysqli($host, $db_user, $db_password, $db_name);
        if(!isset($_SESSION['nick'])) {
            header("Location: zaloguj.php"); 
            exit();
        }

        $problem = $_POST['problem'];
        
        $wszystko_good_post = true;
        
        

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        
        if(strlen($problem) < 10){
            $wszystko_good_post = false;
            $_SESSION['e_problem'] = "Twoje pytanie jest za krótkie";
        }
        if(!isset($_SESSION['id'])){
            $wszystko_good_post = false;
            $_SESSION['e_problem'] = "Zaloguj się";
        }else{
            $id_user = $_SESSION['id'];
        }

        if($wszystko_good_post){
            if($_FILES['photo']!=NULL){
                $photo = $_FILES['photo'];
                $photo = addslashes(file_get_contents($_FILES['photo']['tmp_name']));
            }else{
                $photo = '';
            }
            
 
            $currentDate = gmdate('D-m-y H:i');

            $sql = "INSERT INTO posts VALUES (NULL, '$problem', '$photo', '$id_user', '$currentDate')";
            
            if ($conn->query($sql) === FALSE) {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }
        
        $conn->close();
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/styleForum.css">
    <title>Forum</title>
</head>
<body>
<header id='headerPC'>
        <div id="logo"><img id="logoImg" src="https://th.bing.com/th/id/OIG3.uyOKU__TNibNU8s9VHJW?pid=ImgGn" > ITYevhen</div>
        <div id="menu"><a href="main.php">Główna</a><a href="uslugi.php">Usługi</a><a href="forum.php">Forum</a><a href="zaloguj.php"><div id="ZalogujLink">
            <?php
                if(isset($_SESSION['nick'])){
                    echo 'Panel';
                } else {
                    echo 'Zaloguj/Zarejestruj się';
                }
            ?>
        </div></a></div>
    </header>
    <header id='headerMob'>
        <img id='mobImg' src="img/menu-linie.png" onclick='showMenuMob()' alt="">
        <div id='menuMob'>
            <a href="main.php">Główna</a><br><br>
            <a href="uslugi.php">Usługi</a><br><br>
            <a href="forum.php">Forum</a><br><br>
            <a href="zaloguj.php">
                <?php
                    if(isset($_SESSION['nick'])){
                        echo 'Panel';
                    } else {
                        echo 'Zaloguj/Zarejestruj się';
                    }
                ?>
            </a>
        </div>
    </header>
    <button id='npBut' onclick='npForm()'>zadaj pytanie</button>
    <?php   
        if(isset($_SESSION['e_problem'])){
            echo '<div id="error"><p>'.$_SESSION['e_problem'].'<p></div><br>';
            unset($_SESSION['e_problem']);
        }
    ?>
    <div id='npForm'>
        <form method="post" enctype="multipart/form-data">
            <span onclick='npFormClose()' id='wstecz'>Wstecz</span>
            <h2>Dodaj nowy post</h2>
            <textarea placeholder='Opisz problem' rows="5" name='problem'></textarea>
            <input type="file"  name="photo" id='loadFile'>
            <div id='contImg'></div>
            <input type="submit" value="Dodaj">
        </form>
    </div>
    <?php
        require_once "connect.php";
        $conn = new mysqli($host, $db_user, $db_password, $db_name);
        $showPosts_sql = "SELECT * FROM posts INNER JOIN users ON posts.id_user=users.id_user ORDER BY id DESC";
        $showPost = $conn->query($showPosts_sql);

        if ($showPost->num_rows > 0) {
            while ($row = $showPost->fetch_assoc()) {
                $problem = $row['problem'];
                $id_post = $row['id'];
                $data = $row['data_post'];
                $nick_user_post = $row['nick'];
                $status = $row['status'];
                $photo = $row['photo'];
                
                $showComments_sql = "SELECT comments.*, users.nick, users.status FROM comments JOIN users ON comments.id_user=users.id_user WHERE comments.id_post = $id_post ORDER BY comments.id_comm DESC";
                $showComments = $conn->query($showComments_sql);

                echo '<div class="post"><div class="main"><img class="avatar" src="img/admin.jpg" alt=""><span id="time">'.$data.'</span>';
                echo '<span class="name">'.$nick_user_post.'</span> <span class="status">'.$status.'</span> <p id="text">' . $problem . '</p>';
                if($photo!=NULL){
                    $photo = base64_encode($photo);
                    echo '<img id="photo" src="data:image/jpeg;base64,' . $photo . '"/>';
                }else{
                    echo '<br>';
                }
                
                echo '<div id="likeComm"><img src="img/like1.png" alt="" onclick="like(this)"><img src="img/comm.png" alt="" class="comm-but" onclick="ShowComm(this)"></div><form method="post" id="commForm"><input type="hidden" name="post_id" value="' . $id_post . '"><input type="text" placeholder="Napisz komentarz" name="komentarz" id="inputComment"><input type="submit" id="commInpSub" value="Wyślij"></form></div>';
                echo ' <div class="comments">';
                
                if ($showComments->num_rows > 0) {
                    while ($comment_row = $showComments->fetch_assoc()) {
                        echo '<div class="comment"><img class="avatar" src="img/osoba3.jpg" alt=""><span id="time">'.$comment_row['data_comm'].'</span><span class="name">' . $comment_row['nick'] . '</span><span class="status">'.$comment_row['status'].'</span> <p class="commText">' . $comment_row['text'] . '</p></div>';
                    }
                }
                echo '</div></div>';
            }
        }
        $conn->close();
    ?>
    <script src="scriptOther.js"></script>
    <script src="script.js"></script>
</body>
</html>




















<!-- <div class="post">
        <div class='main'>
            <img class='avatar' src="img/admin.jpg" alt="">
            <span class='name'>admin</span>
            <span class="status">klient</span>
            <p id='text'>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.  </p>
            <img id='photo' src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSKTSasXYaRNvXuQ7F4Y9v1ZVDIEaECgoW2ePZrgZlDFQ&s" alt="">
            <div id='likeComm'><img src="img/like1.png" alt="" onclick="like(this)"><img src="img/comm.png" alt="" class='comm-but'></div>
        </div>
        <div class='comments' style='display: none;'>
            <div class='comment'>
                <img class='avatar' src="img/osoba3.jpg" alt="">
                <span class='name'>Maciej</span>
                <span class="status">klient</span>
                <p class='commText'> Distracted by the readable content of a page when looking at its layout.</p>
            </div>
            <div class='comment'>
                <img class='avatar' src="img/osoba3.jpg" alt="">
                <span class='name'>Maciej</span>
                <span class="status">klient</span>
                <p class='commText'> Distracted by the readable content of a page when looking at its layout.</p>
            </div>
        </div>
    </div> -->