function showMenuMob(){
    var menuMob = document.getElementById('menuMob').style
    if(menuMob.display == 'none'){
      menuMob.display = 'block'
    } else {
      menuMob.display = 'none'
    }
  }