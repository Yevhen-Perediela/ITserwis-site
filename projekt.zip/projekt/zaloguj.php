<?php
session_start();

// Перевірка, чи користувач вже авторизований
if(isset($_SESSION['nick'])){
    if($_SESSION['nick'] == 'admin') {
        header("Location: admin.php"); 
        exit();
    }else if($_SESSION['status_user'] == 'pracownik'){
        header("Location: pracownik.php"); 
        exit();
    }else{
        header("Location: kabinet.php");
    exit();
    }
    
}


if(isset($_POST['nick'])) {
    
    $username = $_POST['nick'];
    $password = $_POST['pass'];
    $username = htmlentities($username, ENT_QUOTES, "UTF-8");

    require_once "connect.php";

    $conn = new mysqli($host, $db_user, $db_password, $db_name);

    
    if ($conn->connect_error) {
        die("Error: " . $conn->connect_error);
    }

    
     $username = mysqli_real_escape_string($conn, $username);

    
     $query = "SELECT * FROM users WHERE nick='$username'";
     $result = $conn->query($query);
 
     if($result->num_rows == 1) {
         $row = $result->fetch_assoc();
         $hashed_password = $row['password'];
         $status = $row['status'];
        
         if(password_verify($password, $hashed_password)) {
             $_SESSION['nick'] = $username; 
             $_SESSION['status_user'] = $status; 
             $_SESSION['email'] = $password;
             $_SESSION['id'] = $row['id_user'];
             if($_SESSION['nick'] == 'admin') {
                header("Location: admin.php"); 
                exit();
            } else if($_SESSION['status_user'] == 'pracownik'){
                header("Location: pracownik.php"); 
                exit();}
            else {
                header("Location: kabinet.php"); 
                exit();
            }
             exit();
         } else {
            $_SESSION['e_zaloguj'] = "Nieprawidłowa nazwa użytkownika lub hasło!";
         }
     } else {
        $_SESSION['e_zaloguj'] = "Użytkownik nie znaleziony!";
     }

    $conn->close(); 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styleLogReg.css"><link rel="stylesheet" href="styleKab.css">
    <link rel="stylesheet" href="css/style.css">
    <title>Zaloguj sie</title>
</head>
<body>
<header id='headerPC'>
        <div id="logo"><img id="logoImg" src="https://th.bing.com/th/id/OIG3.uyOKU__TNibNU8s9VHJW?pid=ImgGn" > ITYevhen</div>
        <div id="menu"><a href="main.php">Główna</a><a href="uslugi.php">Usługi</a><a href="forum.php">Forum</a><a href="zaloguj.php"><div id="ZalogujLink">
            <?php
                if(isset($_SESSION['nick'])){
                    echo 'Kabinet';
                } else {
                    echo 'Zaloguj/Zarejestruj się';
                }
            ?>
        </div></a></div>
    </header>
    <header id='headerMob'>
        <img id='mobImg' src="img/menu-linie.png" onclick='showMenuMob()' alt="">
        <div id='menuMob'>
            <a href="main.php">Główna</a><br><br>
            <a href="uslugi.php">Usługi</a><br><br>
            <a href="forum.php">Forum</a><br><br>
            <a href="zaloguj.php">
                <?php
                    if(isset($_SESSION['nick'])){
                        echo 'Panel';
                    } else {
                        echo 'Zaloguj/Zarejestruj się';
                    }
                ?>
            </a>
        </div>
    </header>
    <?php   
        if(isset($_SESSION['e_logowanie'])){
            echo '<p class="error pEror">'.$_SESSION['e_logowanie'].'<p><br>';
            unset($_SESSION['e_logowanie']);
        }
        if(isset($_SESSION['succ_logowanie'])){
            echo '<p class="error pEror" style="color:green;">'.$_SESSION['succ_logowanie'].'<p><br>';
            unset($_SESSION['succ_logowanie']);
        }
        
        
    ?>
    <div id="forma">
        <form method="post">
            <h2>Zaloguj się</h2>
            <div id="ludzik">
                <div class="eyes" id="eyes1"><div id="eyes21" class="eyes2"></div></div>
                <div class="eyes" id="eyes2"><div id="eyes22" class="eyes2"></div></div>
                <div id="usta"></div>
            </div>
            <input class="input" id="inpNick" type="text" name="nick" oninput="Ludzik(this)" placeholder="Imię">
            <input class="password" type="password" id="password-input" name="pass" oninput="Ludzik2()" placeholder="Hasło">
            <a href='#' class='password-control'  onclick='return show_hide_password(this);'></a>
            
            
            <?php   
                if(isset($_SESSION['e_zaloguj'])){
                    echo '<p class="error">'.$_SESSION['e_zaloguj'].'<p><br>';
                    unset($_SESSION['e_zaloguj']);
                }
            ?>
            <input class="input" id="butt" type="submit" value="Wyślij">
                    

        </form>
    </div>
    <span id="linkRejestr">Nie masz konta? <a href="zarejestruj.php">Zarejestruj się</a></span>
    <script src="script.js"></script>
</body>
</html>