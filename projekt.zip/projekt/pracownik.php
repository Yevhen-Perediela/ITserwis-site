<?php
    session_start();
    require_once 'connect.php';   
    $conn = new mysqli($host, $db_user, $db_password, $db_name);
    if(!isset($_SESSION['nick'])) {
        header("Location: zaloguj.php"); 
        exit();
    }else if($_SESSION['status_user'] == 'admin'){
        header("Location: admin.php"); 
        exit();
    }else if($_SESSION['status_user'] == 'klient'){
        header("Location: kabinet.php");
    exit();
    }

    if($_SERVER["REQUEST_METHOD"] == "POST"){
        
        if(isset($_POST['id_zam'])){
            $sql_prac = "UPDATE zamowienia SET photo_wyk=?, status_zam='Prawie gotowe' WHERE id_zam=?";
            $stmt = $conn->prepare($sql_prac);
            $stmt->bind_param("si", $photo, $_POST['id_zam']);

            $photo = file_get_contents($_FILES['photo']['tmp_name']);
            $stmt->send_long_data(0, $photo);

            $stmt->execute();
        }
    }
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/styleKab.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header id='headerPC'>
        <div id="logo"><img id="logoImg" src="https://th.bing.com/th/id/OIG3.uyOKU__TNibNU8s9VHJW?pid=ImgGn" > ITYevhen</div>
        <div id="menu"><a href="main.php">Główna</a><a href="uslugi.php">Usługi</a><a href="forum.php">Forum</a><a href="zaloguj.php"><div id="ZalogujLink">
            <?php
                if(isset($_SESSION['nick'])){
                    echo 'Panel';
                } else {
                    echo 'Zaloguj/Zarejestruj się';
                }
            ?>
        </div></a></div>
    </header>
    <header id='headerMob'>
        <img id='mobImg' src="img/menu-linie.png" onclick='showMenuMob()' alt="">
        <div id='menuMob'>
            <a href="main.php">Główna</a><br><br>
            <a href="uslugi.php">Usługi</a><br><br>
            <a href="forum.php">Forum</a><br><br>
            <a href="zaloguj.php">
                <?php
                    if(isset($_SESSION['nick'])){
                        echo 'Panel';
                    } else {
                        echo 'Zaloguj/Zarejestruj się';
                    }
                ?>
            </a>
        </div>
    </header>
    <div id='addPracForm'>
        <form method="post" enctype="multipart/form-data">
            <span onclick='npFormClose()' id='wstecz'>Wstecz</span>
            <h4>Dodaj zdjęcie potwierdzające</h4>
            <input type="hidden" name="id_zam" id="hidden_id_zam">
            <input type="file" value='Hello' name="photo" id='loadFile'>
            <input type="submit" value="Wyślij">
        </form>
    </div>
    <div id="kabinetMain">
        <form action="logout.php" method="post" id="wylogujForm">
            <button id="wyloguj" type="submit">Wyloguj się</button>
        </form>
        <img id='adminImg' src="https://img.freepik.com/free-psd/3d-illustration-person-with-sunglasses_23-2149436188.jpg?size=338&ext=jpg&ga=GA1.1.1700460183.1713052800&semt=sph" alt="">
        <p id="imieAdmin"><?php echo $_SESSION['nick']?></p>
        <hr>
        <h3>Zadania do wykonania</h3><br>
        <div class="tableOverflow">
        <table>
                <thead>
                    <th class='thWyk'>Imię</th>
                    <th class='thWyk'>Email</th>
                    <th class='thWyk'>Typ</th>
                    <th class='thWyk' colspan=3>Info</th>
                </thead>  
                <?php   
                    $show_sql = "SELECT * FROM zamowienia JOIN users ON users.id_user=zamowienia.id_user WHERE id_pracownika=".$_SESSION['id']." ORDER BY typ_zam";
                    $show = $conn->query($show_sql);
                    if($show->num_rows > 0){
                        while($row = $show->fetch_assoc()) {
                            $typZam = $row['typ_zam'];
                            $id_zam = $row['id_zam'];
                            $imie = $row['nick'];
                            $email = $row['email'];
                            $kat1 = $row['kategoria1'];
                            $kat2 = $row['kategoria2'];
                            $kat3 = $row['kategoria3'];
                            $status = $row['status_zam'];
                            $szablonBlob = $row["szablon_WWW"];

                           
                            $file = 'szablon_'.$row['id_zam'].'.psd'; 
                            file_put_contents($file, $szablonBlob);
                            if($kat3 == ''){
                                $kat3 = '-';
                            }
                            if($typZam == 'strony WWW'){
                                $kat3 = '<a href="'.$file.'" download="'.$file.'">Pobierz PSD</a>';
                            }
                            
                            if($status == 'W trakcie'){
                                echo "<tr><td>".$imie."</td><td><a href='mailto:".$email."'>".$email."</a></td><td>".$typZam."</td><td>".$kat1."</td><td>".$kat2."</td><td>".$kat3."</td><td><button type='button' onclick='wybierzPrac(".$id_zam.")' id='butNap'>Oznacz</button></td></tr>";        
                                // echo "<tr><td>-</td><td><a>-</a></td><td>".$typZam."</td><td>".$kat1."</td><td>".$kat2."</td><td>".$kat3."</td></tr>";        
                            }
                            if (!$show) {
                                echo "Error: " . $conn->error;
                            }
                        }
                    } else {
                        echo "Brak";
                    }
                    
                ?>
                </table></div>
                </div>
    <script src="scriptAdmin.js"></script>
    <script src="script.js"></script>
</body>
</html>