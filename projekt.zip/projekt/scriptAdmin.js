var strzalkaAdmin = document.getElementById('strzalkaAdmin').style
var WykZadDiv = document.getElementById('WykZadDiv').style
var wykTable = document.getElementById('wykTable').style
var wykTableHeight = document.getElementById('wykTable').style.height
console.log(wykTableHeight);
function WykZad(){
    if(WykZadDiv.height == '300px'){
        WykZadDiv.height = '22px'
        strzalkaAdmin.rotate = '270deg'
        wykTable.display = 'none'
    } else {
        setTimeout(()=>{
            wykTable.display = 'block'
        },700)
        WykZadDiv.height = '300px'
        strzalkaAdmin.rotate = '90deg'
        
        
    }
}

function wybierzPrac(id){
    var npForm = document.getElementById('addPracForm').style
    npForm.display = 'block'
    if(screen.width < 426){
        npForm.animation = 'addPracFormMob 0.7s ease forwards'
    }else{
        npForm.animation = 'addPracForm 0.7s ease forwards'
    }
    
    document.getElementById('hidden_id_zam').value = id
}
function npFormClose(){
    var npForm = document.getElementById('addPracForm').style
    if(screen.width < 426){
        npForm.animation = 'addPracFormCloseMob 0.7s ease forwards'
    }else{
        npForm.animation = 'addPracFormClose 0.7s ease forwards'
    }
    setTimeout(()=>{
        npForm.display = 'none'
    },600)   
}
function showPhoto(a){
    var photo = document.getElementsByClassName('photo')
    for (let i = 0; i < photo.length; i++) {
        photo[a].style.display='block'
        photo[a].style.animation = 'showImg 0.7s ease forwards'
    }
    // var sf = document.getElementById('showPhoto').style
    // sf.display = 'block'
    // sf.animation = 'addPracForm 0.7s ease forwards'
    // document.getElementById('showPhoto').innerHTML = "<span onclick='showPhotoClose()' id='wstecz'>Wstecz</span><?php$showPhoto_sql = 'SELECT * FROM zamowienia WHERE id_zam = "+id+"';$showPhoto = $conn->query($showPhoto_sql); $rowPhoto = $showPhoto->fetch_assoc();$photo = $rowPhoto['photo_wyk'];echo '<img id='photo' src='data:image/jpeg;base64,' . base64_encode($photo) . '/>;' ?><input type='hidden' name='id_zam' id='hidden_id_zam'>"
}


function closeImg(el){
    el.style.animation = 'ImgClose 0.7s ease forwards'
    setTimeout(()=>{
        el.style.display = 'none'
    }, 600)
    
}

// function DodajPrac(){
//     var selectVal = document.getElementById('selectAddId').value
//     document.getElementById('zatrudnienie').innerHTML = "<h3> Czy napewno chcesz zatrudnić "+selectVal+"a?</h3><button>Tak</button>"
// }