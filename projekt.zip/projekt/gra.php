<?php
    session_start();
    if(!isset($_SESSION['nick'])) {
        header("Location: zaloguj.php"); 
        $_SESSION['e_logowanie'] = "Musisz najperw zalogować się!";
        exit();
    }
    require_once 'connect.php';   
    $conn = new mysqli($host, $db_user, $db_password, $db_name);
    
    if($_SERVER["REQUEST_METHOD"] == "POST"){
        if($_POST['score'] != ''){
            $score = $_POST['score'];
            $nick = $_SESSION['id'];
            $sql_readyRow = "INSERT INTO wyniki_gry VALUES (NULL, '$nick', '$score')";
            $rez = $conn->query($sql_readyRow);
            if (!$rez) {
                echo "Error: " . $conn->error;
            }
        }
    }    
?>        
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple JS Game</title>
    <style>
        canvas {
            border: 1px solid black;
        }
    </style>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/styleGra.css">
</head>
<body>
<header>
        <div id="logo"><img id="logoImg" src="https://th.bing.com/th/id/OIG3.uyOKU__TNibNU8s9VHJW?pid=ImgGn" > ITYevhen</div>
        <div id="menu"><a href="main.php">Główna</a><a href="uslugi.php">Usługi</a><a href="forum.php">Forum</a><a href="zaloguj.php"><div id="ZalogujLink">
            <?php
                if(isset($_SESSION['nick'])){
                    echo 'Panel';
                } else {
                    echo 'Zaloguj/Zarejestruj się';
                }
            ?>
        </div></a></div>
    </header>
    <canvas id="gameCanvas" width="800" height="400"></canvas>
    <div id='gameOver'>
        <p id='mainOver'>Przegrałeś!</p>
        <form  method="post" id='form'>
            <input type="hidden" name="score" id='scoreInp'>
            <span id='wynikSpan'>Wynik: <span id='wynik'></span></span>
            <button class='button' type='submit' onclick='ScorePlus()'>Wznów i <span style='color: green;'>zapisz</span> swoje wyniki</button>
            <button class='button' type='submit'>Wznów <span style='color: darkred;'>nie zapisując</span> swoje wyniki</button>
        </form>
    </div>
    <div id='wyniki'>
        <p>Najlepsze wyniki:</p>
        <div id='wynDiv'>

        
        <table>
            <thead>
                <th>Imię</th>
                <th>Wynik</th>
            </thead>
            
                <?php
                    $sql_wyn_show = "SELECT * FROM wyniki_gry JOIN users ON wyniki_gry.id_user = users.id_user  ORDER BY wynik DESC";
                    $rez_show = $conn->query($sql_wyn_show);
                    if($rez_show->num_rows>0){
                        while($row_wyn = $rez_show->fetch_assoc()){
                            $imie =  $row_wyn['nick'];
                            $wynik =  $row_wyn['wynik'];
                            echo "<tr><td>".$imie."</td><td>".$wynik."</td></tr>";
                        }
                    }
                ?>
            
        </table>
        </div>
    </div>
    <script src="scriptGra.js"></script>
</body>
</html>
