<?php
    session_start();
    
    if($_SERVER["REQUEST_METHOD"] == "POST"){
        if(!isset($_SESSION['nick'])) {
            header("Location: zaloguj.php"); 
            $_SESSION['e_logowanie'] = "Musisz najperw zalogować się!";
            exit();
        }
        require_once 'connect.php';   
        $conn = new mysqli($host, $db_user, $db_password, $db_name);
        $id = $_SESSION['id'];
        if(isset($_POST['typStrony']) && isset($_POST['Bezpeczenstwo']) && is_uploaded_file($_FILES['szablon']['tmp_name'])){
            $kat1 = $_POST['typStrony'];
            $kat2 = $_POST['Bezpeczenstwo'];
            // $szablon = addslashes(file_get_contents($_FILES['szablon']['tmp_name']));
          
                // $szablon = $_FILES['szablon'];
                $szablon = addslashes(file_get_contents($_FILES['szablon']['tmp_name']));
            
                mysqli_options($conn, MYSQLI_OPT_CONNECT_TIMEOUT, 300);


            $sql = "INSERT INTO zamowienia VALUES (NULL, '$id', 'strony WWW', '$kat1', '$kat2', NULL, '$szablon', 'W trakcie', NULL, NULL)";
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            if ($conn->query($sql) === TRUE) {
                $_SESSION['success_uslugi'] = "Zamowienie zostało wysłane";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        } else{
            if((!isset($_POST['typStrony']) || !isset($_POST['Bezpeczenstwo']) || !isset($_POST['szablon']))and(isset($_POST['typStrony']) || isset($_POST['Bezpeczenstwo']) || isset($_POST['szablon']))){
                $_SESSION['e_uslugi'] = "Nie wybrałeś coś";
            }
            
        }
        if(isset($_POST['urzadzenie']) && isset($_POST['niedziala'])){
            $kat1 = $_POST['urzadzenie'];
            $kat2 = $_POST['niedziala'];
            

            $sql = "INSERT INTO zamowienia VALUES (NULL, '$id', 'naprawa', '$kat1', '$kat2', NULL, NULL, 'W trakcie', NULL, NULL)";
            
            if ($conn->query($sql) === TRUE) {
                $_SESSION['success_uslugi'] = "Zamowienie zostało wysłane";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        } else{
            if(isset($_POST['urzadzenie']) && !isset($_POST['niedziala'])){
                $_SESSION['e_uslugi'] = "Nie wybrałeś problemu z urządzeniem";
            }else if(!isset($_POST['urzadzenie']) && isset($_POST['niedziala'])){
                $_SESSION['e_uslugi'] = "Nie wybrałeś typ urządzeniem";
            } 
            
        }
        if(isset($_POST['os']) && isset($_POST['ram']) && isset($_POST['storage'])){
            $kat1 = $_POST['os'];
            $kat2 = $_POST['ram'];
            $kat3 = $_POST['storage'];

            $sql = "INSERT INTO zamowienia VALUES (NULL, '$id', 'serwer', '$kat1', '$kat2', '$kat3', NULL, 'W trakcie', NULL, NULL)";
            
            if ($conn->query($sql) === TRUE) {
                $_SESSION['success_uslugi'] = "Zamowienie zostało wysłane";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }else{
            if((!isset($_POST['os']) || !isset($_POST['ram']) || !isset($_POST['storage']))and(isset($_POST['os']) || isset($_POST['ram']) || isset($_POST['storage']))){
                $_SESSION['e_uslugi'] = "Nie wybrałeś coś";
            }
        }
        
        $conn->close();
    }   
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/styleUsl.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header id='headerPC'>
        <div id="logo"><img id="logoImg" src="https://th.bing.com/th/id/OIG3.uyOKU__TNibNU8s9VHJW?pid=ImgGn" > ITYevhen</div>
        <div id="menu"><a href="main.php">Główna</a><a href="uslugi.php">Usługi</a><a href="forum.php">Forum</a><a href="zaloguj.php"><div id="ZalogujLink">
            <?php
                if(isset($_SESSION['nick'])){
                    echo 'Kabinet';
                } else {
                    echo 'Zaloguj/Zarejestruj się';
                }
            ?>
        </div></a></div>
    </header>
    <header id='headerMob'>
        <img id='mobImg' src="img/menu-linie.png" onclick='showMenuMob()' alt="">
        <div id='menuMob'>
            <a href="main.php">Główna</a><br><br>
            <a href="uslugi.php">Usługi</a><br><br>
            <a href="forum.php">Forum</a><br><br>
            <a href="zaloguj.php">
                <?php
                    if(isset($_SESSION['nick'])){
                        echo 'Panel';
                    } else {
                        echo 'Zaloguj/Zarejestruj się';
                    }
                ?>
            </a>
        </div>
    </header>

    <div id="kontakt">
        <div class="UslSpan"><span class="dopSpan">Telefon:</span> +48 347 209 598</div> 
        <div class="UslSpan"><span class="dopSpan">Email:</span> ityevhen@gmail.com</div>
    </div>
    <h1>Zamów online</h1>
    <?php   
        if(isset($_SESSION['e_uslugi'])){
            echo '<p class="error">'.$_SESSION['e_uslugi'].'<p><br>';
            unset($_SESSION['e_uslugi']);
        }
        if(isset($_SESSION['success_uslugi'])){
            echo '<p class="success">'.$_SESSION['success_uslugi'].'<p><br>';
            unset($_SESSION['success_uslugi']);
        }
    ?>
    <form method="post" enctype="multipart/form-data">
        <div class="uslugi">
            <div onclick="more(0)">
                <h3 id='h3first' class="h3">Tworzenie strony internetowej</h3>
                <img class="strzalka" id='strzalka1' src="https://img.redro.pl/fototapety/ikona-strzalki-w-lewo-400-144585352.jpg" alt="">
            </div>
            
            <div class="uslugiDiv"></div>
        </div>
        <div class="uslugi" >
            <div onclick="more(1)">
                <h3 class="h3">Naprawa sprzętu</h3>
                <img class="strzalka" src="https://img.redro.pl/fototapety/ikona-strzalki-w-lewo-400-144585352.jpg" alt="">
                
            </div>
            <div class="uslugiDiv">
                
            </div>
        </div>
        <div class="uslugi">
            <div onclick="more(2)">
                <h3 class="h3">Konfiguracja serwera</h3>
                <img class="strzalka" src="https://img.redro.pl/fototapety/ikona-strzalki-w-lewo-400-144585352.jpg" alt="">
            </div>
            <div class="uslugiDiv">
    
            </div>
        </div>




    </form>
     
    
    <script src="scriptUslugi.js"></script>
    
</body>
</html>






























<!-- 
<input type="radio" name="urzadzenie" value="komputer" class="radio">
        <input type="radio" name="urzadzenie" value="laptop" class="radio">
        <input type="radio" name="urzadzenie" value="telefon" class="radio"> 

        <input type="radio" name="niedziala" class="radio" value="bateria">
        <input type="radio" name="niedziala" class="radio" value="ekran">
        <input type="radio" name="niedziala" class="radio" value="klawiatura">
        <input type="radio" name="niedziala" class="radio" value="kamera">
        <input type="radio" name="niedziala" class="radio" value="nie wiadomo/inne"> 

        
        <input type="radio" name="os" class="radio" value="linux">
        <input type="radio" name="os" class="radio" value="windows server">
        <input type="radio" name="ram" class="radio" value="16">
        <input type="radio" name="ram" class="radio" value="32">
        <input type="radio" name="ram" class="radio" value="64">
        <input type="radio" name="storage" class="radio" value="512">
        <input type="radio" name="storage" class="radio" value="1">
        <input type="radio" name="storage" class="radio" value="2"> -->










            <!-- NAPRAWA -->
<!-- 
            <span class="spanUsl">Typ urządzenia:</span><br>
            <div id="imgs">
                <img src="computer.png" onclick="UslugaSprzet(0, 200)"><img src="laptop.png" onclick="UslugaSprzet(1, 300)"><img src="smartphone.png" onclick="UslugaSprzet(2, 150)">
            </div><br>
            <span class="spanUsl">Co nie działa:</span><br><br>
            <div id="niedziala">
                <span  onclick="UslugaSprzet(3, 100)">Bateria</span><span onclick="UslugaSprzet(4, 150)">Ekran</span><span onclick="UslugaSprzet(5, 50)">Klawiatura</span><span onclick="UslugaSprzet(6, 120)">Kamera</span><span onclick="UslugaSprzet(7, 0)">Nie wiadomo/inne</span>
            </div>
            <div id="wynikNaprawa">Przybliżony koszt usługi: <span id="wynikNap">0</span> zł</div>
            <input type="submit" class="wynikButt" value="Wyślij"> -->




            <!-- SERWERY -->


            <!-- <br><span class="spanUsl">System operacyjny:</span><br>
            <div id="imgs">
                <img src="linux.png" onclick="UslugaSprzet(0, 400)"><img style="padding: 0px; width: 100px;" id="windowsImg" src="windows.jpg" onclick="UslugaSprzet(1, 450)">
            </div><br>
            <span class="spanUsl">RAM:</span><br><br>
            <div id="niedziala">
                <span  onclick="UslugaSprzet(3, 100)">16 GB</span><span onclick="UslugaSprzet(4, 200)">32 Gb</span><span onclick="UslugaSprzet(5, 350)">64 GB</span>
            </div><br><br>
            <span class="spanUsl">HDD/SSD:</span><br><br>
            <div id="niedziala">
                <span  onclick="UslugaSprzet(3, 150)">512 GB</span><span onclick="UslugaSprzet(4, 500)">1 TB</span><span onclick="UslugaSprzet(5, 700)">2 TB</span>
            </div>
            <div id="wynikNaprawa">Przybliżony koszt usługi: <span id="wynikNap">0</span> zł</div>
            <input type="submit" class="wynikButt" value="Wyślij"> -->