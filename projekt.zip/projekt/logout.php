<?php
session_start();
if(!isset($_SESSION['nick'])) {
    header("Location: login.php"); 
    exit();
}
$_SESSION = array();
session_unset();
session_destroy();
header("Location: zaloguj.php");
exit();
?>
