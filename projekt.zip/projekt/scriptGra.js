// Get the canvas element and its context
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

// Player object
const player = {
    x: 50,
    y: canvas.height / 2,
    width: 40,
    height: 40,
    speed: 5,
    score: 0
};

// Enemy object
class Enemy {
    constructor() {
        this.x = canvas.width - 20;
        this.y = Math.random() * canvas.height;
        this.width = 50;
        this.height = 50;
        this.speed = 3;
    }
    update() {
        this.x -= this.speed;
    }
}
class GoodEnemy {
    constructor() {
        this.x = canvas.width - 20;
        this.y = Math.random() * canvas.height;
        this.width = 50;
        this.height = 50;
        this.speed = 3;
    }
    update() {
        this.x -= this.speed;
    }
}

// Array to hold enemies
const enemies = [];
const goodEnemies = [];

// Variables to track key states
let upPressed = false;
let downPressed = false;
let spacePressed = false;

// Event listeners for keypress
document.addEventListener("keydown", keyDownHandler, false);
document.addEventListener("keyup", keyUpHandler, false);

// Functions to handle key events
function keyDownHandler(e) {
    if (e.key === "s") {
        upPressed = true;
    } 
    if (e.key === "w") {
        downPressed = true;
    }
    if (e.key === " ") {
        spacePressed = true;
    }
}

function keyUpHandler(e) {
    if (e.key === "s") {
        upPressed = false;
    } 
    if (e.key === "w") {
        downPressed = false;
    }
    if (e.key === " ") {
        spacePressed = false;
    }
}

// Function to draw player
function drawPlayer() {
    ctx.beginPath();
    player_image = new Image();
    player_image.src = 'img/gra_people.png';
    ctx.drawImage(player_image, player.x, player.y, player.width, player.height);
    ctx.fillStyle = "#0095DD";
    ctx.fill();
    ctx.closePath();
}

// Function to draw enemies
function drawEnemies() {
    enemies.forEach(enemy => {
        enemies_image = new Image();
        enemies_image.src = 'img/gra1.png';
        ctx.beginPath();
        ctx.drawImage(enemies_image, enemy.x, enemy.y, enemy.width, enemy.height);
        ctx.fillStyle = "#FF0000";
        ctx.fill();
        ctx.closePath();
    });
    
}
function drawGoodEnemies() {
    goodEnemies.forEach(goodEnemy => {
        enemies_image2 = new Image();
        enemies_image2.src = 'img/gra2.png';
        ctx.beginPath();
        ctx.drawImage(enemies_image2, goodEnemy.x, goodEnemy.y, goodEnemy.width, goodEnemy.height);
        ctx.fillStyle = "#FF0000";
        ctx.fill();
        ctx.closePath();
    });
    
}
let highestScore = 0;
// Function to handle game logic
function updateGame() {
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Move player
    if (upPressed && player.y > 0) {
        player.y -= player.speed;
    }
    if (downPressed && player.y < canvas.height - player.height) {
        player.y += player.speed;
    }

    // Draw player
    drawPlayer();

    // Update and draw enemies
    drawEnemies();
    enemies.forEach(enemy => {
        enemy.update();
    });
    drawGoodEnemies();
    goodEnemies.forEach(goodEnemy => {
        goodEnemy.update();
    });

    // Collision detection
    enemies.forEach((enemy, index) => {
        if (player.x < enemy.x + enemy.width &&
            player.x + player.width > enemy.x &&
            player.y < enemy.y + enemy.height &&
            player.y + player.height > enemy.y) {
            // Collision detected
            enemies.splice(index, 1);
            player.score--;
        }
    });
    goodEnemies.forEach((goodEnemy, index) => {
        if (player.x < goodEnemy.x + goodEnemy.width &&
            player.x + player.width > goodEnemy.x &&
            player.y < goodEnemy.y + goodEnemy.height &&
            player.y + player.height > goodEnemy.y) {
            // Collision detected
            goodEnemies.splice(index, 1);
            player.score++;
        }
    });

    if (player.score > highestScore) {
        highestScore = player.score;
    }
    // Check if player lost
    if (player.score < 0) {
        document.getElementById('wynik').innerHTML = highestScore
        document.getElementById('gameOver').style.display = 'block'
        return; // Stop the game loop
    }
    
    // Generate new enemy
    if (Math.random() < 0.06) {
        enemies.push(new Enemy());
    }
    if (Math.random() < 0.02) {
        goodEnemies.push(new GoodEnemy());
    }

    // Display score
    ctx.font = "16px Arial";
    ctx.fillStyle = "#000";
    ctx.fillText("Score: " + player.score, 10, 20);

    // Call updateGame function recursively if the game is still running
    if (player.score >= 0) {
        requestAnimationFrame(updateGame);
    }
}

function ScorePlus(){
    document.getElementById('scoreInp').value = highestScore
} 


// Start the game loop
updateGame();
