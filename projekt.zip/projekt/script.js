
const moveable = document.querySelector('#div1Img');
const paralaxObj = document.getElementsByClassName('paralaxObj')
const body = document.querySelector('body');

body.addEventListener('mousemove', function(e) {

  const moveableX = (e.clientX / body.offsetWidth);
  const moveableY = (e.clientY / body.offsetHeight);

  for(var i=0;i<paralaxObj.length;i++){
    paralaxObj[i].style.transform = `translate(-${moveableX * 100}%, -${moveableY * 100}%)`;
  }
  moveable.style.transform = `translate(-${moveableX *100}%, -${moveableY*10}%)`;
});


var eyes21 = document.getElementById('eyes21')
var eyes22 = document.getElementById('eyes22')
var eyes1 = document.getElementById('eyes1')
var eyes2 = document.getElementById('eyes2')
var usta = document.getElementById('usta')
var inp = document.getElementById('inpNick')
var eyes = document.getElementsByClassName('eyes')
var dlugoscPrzed = inp.value.length
var marginLeft1 = 17
var marginLeft1Eye2 = 55
var marginLeft2 = 5
var marginTop = 8

function Ludzik(input){
  eyes1.style = 'height:23px; border: 0px; margin-left:15px;' 
  eyes2.style = 'height:23px; border:0px;margin-left:48px;' 
  var dlugoscTeraz = input.value.length

  if(dlugoscTeraz > dlugoscPrzed){
    marginLeft2+=0.3
    marginLeft1+=0.3
    marginLeft1Eye2+=0.3
    if(marginTop<12){
      marginTop+=0.2
    } 
    if(marginLeft1 < 29 && marginLeft2 <20){
      eyes21.style = 'margin-left:'+marginLeft2+'px; margin-top:'+marginTop+'px;'
      eyes22.style = 'margin-left:'+marginLeft2+'px; margin-top:'+marginTop+'px;'
      eyes1.style.marginLeft = marginLeft1+'px'
      eyes2.style.marginLeft = marginLeft1Eye2+'px'
      usta.style.height = marginLeft2+'px'
    } 
  } 
  
  if(dlugoscTeraz < dlugoscPrzed){
    marginLeft2-=0.3
    marginLeft1-=0.3
    marginLeft1Eye2-=0.3
    if(marginLeft1 < 29 && marginLeft2 <20){
      eyes21.style.marginLeft = marginLeft2+'px'
      eyes22.style.marginLeft = marginLeft2+'px'
      eyes1.style.marginLeft = marginLeft1+'px'
      eyes2.style.marginLeft = marginLeft1Eye2+'px'
      usta.style.height = marginLeft2+'px'
    }
  }
  console.log(dlugoscTeraz, dlugoscPrzed, '----', marginLeft1, marginLeft2, marginTop);
  dlugoscPrzed = dlugoscTeraz
  eyes21.style.display = 'block'
  eyes22.style.display = 'block'
}

function Ludzik2(){
  eyes1.style = 'height:3px; border-top: 2px solid black; margin-left:20px;' 
  eyes2.style = 'height:3px; border-top: 2px solid black; margin-left:55px;' 
  eyes21.style.display = 'none'
  eyes22.style.display = 'none'
}








function Menu1(){
  var menu = document.querySelector('.mobileMenu');
  menu.classList.toggle('active');
  if(menu.classList.contains('active')){
      document.getElementById('menuImg').src='close.png';
  } else {
      document.getElementById('menuImg').src='menu-linie.png';
  }
};

var textFaq = ''
function faq(a){
  var faqDiv = document.getElementById('questions')
  if(a==1 && faqDiv.width != '300px'){
    faqDiv.style.animation = 'none'
    textFaq = 'Masz pytanie?<br><br>Śmiało pytaj'
  } else if(a==0) {
    if(faqDiv.width == '70px'){
      faqDiv.style.animation = 'rotate 4s linear infinite'  
    }
    textFaq = '<img src="img/faq.png">'
  } else if(a==2){
    faqDiv.style = 'width:300px; height: 300px; margin-left:75%; margin-top: 180px; animation: none;'
    textFaq = 'Hello'
  }
  faqDiv.innerHTML = textFaq
}




function show_hide_password(target){
	var input = document.getElementById('password-input');
  
	if (input.getAttribute('type') == 'password') {
		target.classList.add('view');
		input.setAttribute('type', 'text');
    Ludzik(input)
  //   eyes21.style = 'margin-left:'+marginLeft2+'px; margin-top:'+marginTop+'px;'
  //     eyes22.style = 'margin-left:'+marginLeft2+'px; margin-top:'+marginTop+'px;'
  //   eyes1.style = 'height:23px; border: 0px; margin-left:15px;' 
  // eyes2.style = 'height:23px; border:0px;margin-left:48px;' 
	} else {
    
		target.classList.remove('view');
		input.setAttribute('type', 'password');
    Ludzik2()
	}
	return false;
}


function Color(el){
  var reg = document.getElementById('regulamin').style
  var a = document.getElementsByTagName('a')
  if(el == 1){
    for (let i = 0; i < a.length; i++) {
      a[i].style.color = 'green'
      
    }
    reg.color= 'green'
    reg.backgroundColor = 'darkgrey'
    document.getElementById('logo').style.color = 'green'
  }
  if(el == 2){
    for (let i = 0; i < a.length; i++) {
      a[i].style.color = 'whitesmoke'
      
    }
    reg.color= 'whitesmoke'
    reg.backgroundColor = 'rgb(36, 36, 36)'
    document.getElementById('logo').style.color = 'whitesmoke'
  }
}

function showMenuMob(){
  var menuMob = document.getElementById('menuMob').style
  var menuMobA = document.querySelectorAll('#menuMob a')
  if(menuMob.display == 'none'){
    menuMob.display = 'block'
    menuMob.animation = 'menuMob 0.5s linear forwards'
    for (let i = 0; i < menuMobA.length; i++) {
      menuMobA[i].style.animation = 'menuMob 0.5s linear'
    }
  } else {
    for (let i = 0; i < menuMobA.length; i++) {
      menuMobA[i].style.animation = 'menuMobClose 0.5s linear'
    }
    menuMob.animation = 'menuMobClose 0.5s linear'
    setTimeout(()=>{
      menuMob.display = 'none'
    }, 480)
    
  }
}