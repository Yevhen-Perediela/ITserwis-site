<?php
    session_start();

    if(!isset($_SESSION['nick'])) {
        header("Location: zaloguj.php"); 
        exit();
    }else if($_SESSION['status_user'] == 'pracownik'){
        header("Location: pracownik.php"); 
        exit();
    }else if($_SESSION['status_user'] == 'pracownik'){
        header("Location: kabinet.php");
        exit();
    
        }

    require_once 'connect.php';   
    $conn = new mysqli($host, $db_user, $db_password, $db_name);


    
    if($_SERVER["REQUEST_METHOD"] == "POST"){
        // Potwierdzenie od administratora
        if(isset($_POST['checkbox'])){
            $idRow = $_POST['checkbox'];
            $sql_readyRow = "UPDATE zamowienia SET status_zam='Gotowe' WHERE id_zam='$idRow'";
            $rez = $conn->query($sql_readyRow);
            if (!$rez) {
                echo "Error: " . $conn->error;
            }
        }
        // wybieranie pracownika dla wykonania zadania
        if(isset($_POST['pracownik'])){
            $sql_prac = "UPDATE zamowienia SET id_pracownika=".$_POST['pracownik']." WHERE id_zam =".$_POST['id_zam']."";
            $conn -> query($sql_prac);
        }
        
        if(isset($_POST['addPrac'])){
            $sql_prac_add = "UPDATE users SET status='pracownik' WHERE nick = '{$_POST['addPrac']}'";
            $conn->query($sql_prac_add);
        }
        if(isset($_POST['usunPrac'])){
            $sql_prac_usun = "UPDATE users SET status='klient' WHERE nick = '{$_POST['usunPrac']}'";
            $conn->query($sql_prac_usun);
        }
    }
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/styleKab.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header id='headerPC'>
        <div id="logo"><img id="logoImg" src="https://th.bing.com/th/id/OIG3.uyOKU__TNibNU8s9VHJW?pid=ImgGn" > ITYevhen</div>
        <div id="menu"><a href="main.php">Główna</a><a href="uslugi.php">Usługi</a><a href="forum.php">Forum</a><a href="zaloguj.php"><div id="ZalogujLink">
            <?php
                if(isset($_SESSION['nick'])){
                    echo 'Panel';
                } else {
                    echo 'Zaloguj/Zarejestruj się';
                }
            ?>
        </div></a></div>
    </header>
    <header id='headerMob'>
        <img id='mobImg' src="img/menu-linie.png" onclick='showMenuMob()' alt="">
        <div id='menuMob'>
            <a href="main.php">Główna</a><br><br>
            <a href="uslugi.php">Usługi</a><br><br>
            <a href="forum.php">Forum</a><br><br>
            <a href="zaloguj.php">
                <?php
                    if(isset($_SESSION['nick'])){
                        echo 'Panel';
                    } else {
                        echo 'Zaloguj/Zarejestruj się';
                    }
                ?>
            </a>
        </div>
    </header>
    <!-- wybieranie pracownika dla wykonania zadania -->
    <div id='addPracForm'>
        <form method="post">
            <span onclick='npFormClose()' id='wstecz'>Wstecz</span>
            <h4>Wybierz pracownika do wykonania tego zadania</h4>
            <input type="hidden" name="id_zam" id="hidden_id_zam">
            <select name="pracownik">
                <?php
                    $sql_prac_zad = "SELECT id_user, nick FROM users WHERE status = 'pracownik'";
                    $rez_prac_zad = $conn->query($sql_prac_zad);
                    if($rez_prac_zad->num_rows>0){
                        while($row_prac_zad = $rez_prac_zad->fetch_assoc()){
                            echo $row_prac_zad['id_user'];
                            echo "<option value=".$row_prac_zad['id_user'].">".$row_prac_zad['nick']."</option>";
                        }
                    }
                ?>
            </select>
            <input type="submit" value="Wyślij zadanie">
        </form>
    </div>
    
    <div id="kabinetMain">
        <form action="logout.php" method="post" id="wylogujForm">
            <button id="wyloguj" type="submit">Wyloguj się</button>
        </form>
        <img id='adminImg' src="https://img.freepik.com/free-psd/3d-illustration-person-with-sunglasses_23-2149436188.jpg?size=338&ext=jpg&ga=GA1.1.1700460183.1713052800&semt=sph" alt="">
        <p id="imieAdmin">Admin</p>
        <hr>
        <!-- 3 formularza dla wyświetlania zadań  -->
        <form method='post' id='adminForm'>
        <h3>Strony internetowe</h3><br>
        <div class="tableOverflow">
        <table>
            <thead>
                <th>Imię</th>
                <th>Email</th>
                <th>Typ strony</th>
                <th>Bezpeczeństwo</th>
                <th style='font-size: 13px;'>Wybierz <br> pracownika</th>
            </thead>
            <?php   
                $sql_strony = "SELECT * FROM zamowienia JOIN users ON zamowienia.id_user = users.id_user WHERE typ_zam = 'strony WWW' AND id_pracownika IS NULL";
                $rez_nap = $conn->query($sql_strony);
                // var_dump($conn);
                if ($conn->connect_error) {
                    die("Error " . $conn->connect_error);
                }
                if($rez_nap->num_rows > 0){
                    while($row_nap = $rez_nap->fetch_assoc()){
                        $typZam_nap = $row_nap['typ_zam'];
                        $idZam_nap = $row_nap['id_zam'];
                        $imie_nap = $row_nap['nick'];
                        $email_nap = $row_nap['email'];
                        $kat1_nap = $row_nap['kategoria1'];
                        $kat2_nap = $row_nap['kategoria2'];
                        $status_nap = $row_nap['status_zam'];

                        if($typZam_nap == 'strony WWW' && $status_nap == 'W trakcie'){
                            echo "<tr><td>".$imie_nap."</td><td><a href='mailto:".$email_nap."'>".$email_nap."</a></td><td>".$kat1_nap."</td><td>".$kat2_nap."</td><td><button onclick='wybierzPrac(".$idZam_nap.")' type='button' id='butNap'>Wybierz</button></td></tr>";        
                        }
                    }
                } else {
                    echo 'Brak';
                }
            ?>

        </table>
        </div>
         <br>
        <h3>Naprawa</h3><br>
        <div class="tableOverflow">
        <table>
            <thead>
                <th>Imię</th>
                <th>Email</th>
                <th>Urządzenie</th>
                <th>Nie działa</th>
                <th style='font-size: 13px;'>Wybierz <br> pracownika</th>
            </thead>
            <?php   
                $sql_naprawa = "SELECT * FROM zamowienia JOIN users ON zamowienia.id_user = users.id_user WHERE typ_zam = 'naprawa' AND id_pracownika IS NULL";
                $rez_nap = $conn->query($sql_naprawa);
                // var_dump($conn);
                if ($conn->connect_error) {
                    die("Error " . $conn->connect_error);
                }
                if($rez_nap->num_rows > 0){
                    while($row_nap = $rez_nap->fetch_assoc()){
                        $typZam_nap = $row_nap['typ_zam'];
                        $idZam_nap = $row_nap['id_zam'];
                        $imie_nap = $row_nap['nick'];
                        $email_nap = $row_nap['email'];
                        $kat1_nap = $row_nap['kategoria1'];
                        $kat2_nap = $row_nap['kategoria2'];
                        $status_nap = $row_nap['status_zam'];

                        if($typZam_nap == 'naprawa' && $status_nap == 'W trakcie'){
                            echo "<tr><td>".$imie_nap."</td><td><a href='mailto:".$email_nap."'>".$email_nap."</a></td><td>".$kat1_nap."</td><td>".$kat2_nap."</td><td><button onclick='wybierzPrac(".$idZam_nap.")' type='button' id='butNap'>Wybierz</button></td></tr>";        
                        }
                    }
                } else {
                    echo 'Brak';
                }
            ?>

        </table></div> <br>
        <h3>Konfiguracja</h3><br>
        <div class="tableOverflow">
        <table>
            <thead>
                <th>Imię</th>
                <th>Email</th>
                <th>OS</th>
                <th>RAM</th>
                <th>Storage</th>
                <th style='font-size: 13px;'>Wybierz <br> pracownika</th>
            </thead>  
            <?php   
                $show_sql2 = "SELECT * FROM zamowienia JOIN users ON users.id_user=zamowienia.id_user WHERE id_pracownika IS NULL";
                $show2 = $conn->query($show_sql2);
                if($show2->num_rows > 0){
                    while($row = $show2->fetch_assoc()) {
                        $typZam = $row['typ_zam'];
                        $idZam = $row['id_zam'];
                        $imie = $row['nick'];
                        $email = $row['email'];
                        $kat1 = $row['kategoria1'];
                        $kat2 = $row['kategoria2'];
                        $kat3 = $row['kategoria3'];
                        $status = $row['status_zam'];
                        
                        if($typZam == 'serwer' && $status == 'W trakcie'){
                            echo "<tr><td>".$imie."</td><td><a href='mailto:".$email."'>".$email."</a></td><td>".$kat1."</td><td>".$kat2."</td><td>".$kat3."</td><td><button onclick='wybierzPrac(".$idZam.")' type='button' id='butNap'>Wybierz</button></td></tr>";        
                        }
                    }
                } else {
                    echo "Brak";
                }
                
            ?>  
        </table></div></form><br>
        <hr>
        
        <h3>Oczekuje na potwierdzenie</h3><br>
        <div class="tableOverflow">
        <table>
            <thead>
                <th>Imię klienta</th>
                <th>Email klienta</th>
                <th>Pracownik</th>
                <th>Zdjęcie</th>
                <th>Wyślij <br>do klienta</th>
                
            </thead>  
            <?php   
                $i_photo = 0;
                mysqli_options($conn, MYSQLI_OPT_CONNECT_TIMEOUT, 300);
                $show_sql_potwierdz = "SELECT  user.nick AS userNick, zamowienia.photo_wyk, user.email, zamowienia.status_zam, zamowienia.id_zam, pracownik.nick AS pracNick FROM zamowienia JOIN users AS user ON user.id_user=zamowienia.id_user JOIN users AS pracownik ON pracownik.id_user=zamowienia.id_pracownika";
                $show3 = $conn->query($show_sql_potwierdz);
                if($show3->num_rows > 0){
                    while($row_potwierdz = $show3->fetch_assoc()) {
                        $idZam = $row_potwierdz['id_zam'];
                        $imie = $row_potwierdz['userNick'];
                        $imie_prac = $row_potwierdz['pracNick'];
                        $email = $row_potwierdz['email'];
                        $status = $row_potwierdz['status_zam'];
                        $photo = $row_potwierdz['photo_wyk'];
                        // wyswietlania photo od pracownika
                        // if($photo != ''){
                            
                        // }
                        if($status == 'Prawie gotowe'){
                            echo '<div class="photo"onclick="closeImg(this)"><img id="photo_wyk"  src="data:image/jpeg;base64,' . base64_encode($photo) . '"/></div>';
                            echo "<tr><td>".$imie."</td><td><a href='mailto:".$email."'>".$email."</a></td><td>".$imie_prac."</td><td><button onclick='showPhoto(".$i_photo.")' type='button' id='butNap'>Otwórz</button></td><td><form method='POST'><input class='inpCheck' type='checkbox' name='checkbox' value=".$idZam." onchange='submit()'></form></td></tr>";        
                            $i_photo++;
                        }
                    }
                } else {
                    echo "Brak";
                }
            ?>  
        </table></div></form>
        <hr>
        <div onclick="WykZad()" id="WykZadDiv">
            <h3 id='h3Wyk'>Wykonane</h3><br>
            <img class="strzalka" id='strzalkaAdmin' src="https://img.redro.pl/fototapety/ikona-strzalki-w-lewo-400-144585352.jpg" alt="">
            <div id='wykTable'>
            <table>
                <thead>
                    <th class='thWyk'>Imię</th>
                    <th class='thWyk'>Email</th>
                    <th class='thWyk'>Typ</th>
                    <th class='thWyk' colspan=3>Info</th>
                </thead>  
                <?php   
                    $show_sql = "SELECT * FROM zamowienia JOIN users ON users.id_user=zamowienia.id_user ORDER BY typ_zam";
                    $show = $conn->query($show_sql);
                    if($show->num_rows > 0){
                        while($row = $show->fetch_assoc()) {
                            $typZam = $row['typ_zam'];
                            $imie = $row['nick'];
                            $email = $row['email'];
                            $kat1 = $row['kategoria1'];
                            $kat2 = $row['kategoria2'];
                            $kat3 = $row['kategoria3'];
                            $status = $row['status_zam'];
                            if($kat3 == ''){
                                $kat3 = '-';
                            }
                            if($status == 'Gotowe'){
                                echo "<tr><td>".$imie."</td><td><a href='mailto:".$email."'>".$email."</a></td><td>".$typZam."</td><td>".$kat1."</td><td>".$kat2."</td><td>".$kat3."</td></tr>";        
                            }
                            if (!$show) {
                                echo "Error: " . $conn->error;
                            }
                        }
                    } else {
                        echo "Brak";
                    }
                ?>
            </table>
        </div> 
                  
    </div>
    <hr> 
    <form method='post'>
    <div style='display: inline-flex; width:100%;'>
    
        <div id='zatrudnienie'>
            <h3>Zatrudnij nowego pracownika</h3>
            
            <select name="newPracownik" class="selectAdd" id='selectAddId'>
                <?php
                    $zatr_sql = "SELECT * FROM users WHERE status != 'pracownik'";
                    $zatr = $conn->query($zatr_sql);
                    if($zatr->num_rows > 0){
                        while($row_zatr = $zatr->fetch_assoc()) {
                            // $id_new_prac = $row_zatr['id_user'];
                            $imie_new_prac = $row_zatr['nick'];
                            echo "<option class='selectAdd' value='$imie_new_prac'>$imie_new_prac</option>";
                        }
                    } else {
                        echo "Brak";
                    }
                ?>
            </select>
            <button onclick='DodajPrac()'>Dodaj</button>
        </div>
        
       

        <div id='zwolnienie'>
            <h3>Zwolnij pracownika</h3>
            <select name="newPracownik" class="selectAdd" id='selectUsunId'>
                <?php
                    $zatr_sql = "SELECT * FROM users WHERE status = 'pracownik'";
                    $zatr = $conn->query($zatr_sql);
                    if($zatr->num_rows > 0){
                        while($row_zatr = $zatr->fetch_assoc()) {
                            // $id_new_prac = $row_zatr['id_user'];
                            $imie_new_prac = $row_zatr['nick'];
                            echo "<option class='selectAdd' value='$imie_new_prac'>$imie_new_prac</option>";
                        }
                    } else {
                        echo "Brak";
                    }
                ?>
            </select>
            <button onclick='UsunPrac()'>Usuń</button>
        </div>
    </div>
    <input type='hidden' value='' id='hiddenInp' name='addPrac'>
    <input type='hidden' value='' id='hiddenInp2' name='usunPrac'>
    </form>
    <script>
            function DodajPrac(){
                var selectVal = document.getElementById('selectAddId').value;
                document.getElementById('zatrudnienie').innerHTML = "<h3> Czy napewno chcesz zatrudnić <span style='color: rgb(190, 190, 190); font-size:25px;'>"+selectVal+"</span>a?</h3><button style='margin-top: 17px;' type='submit'>Tak</button>";
                document.getElementById('hiddenInp').value = selectVal
            }
            function UsunPrac(){
                var selectVal2 = document.getElementById('selectUsunId').value;
                document.getElementById('zwolnienie').innerHTML = "<h3> Czy napewno chcesz zwolnić <span style='color: rgb(190, 190, 190); font-size:25px;'>"+selectVal2+"</span>a?</h3><button style='margin-top: 17px;' type='submit'>Tak</button>";
                document.getElementById('hiddenInp2').value = selectVal2
            }
        </script>
    <script src="scriptAdmin.js"></script>
    <script src="script.js"></script>
</body>
</html>
