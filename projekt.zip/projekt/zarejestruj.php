<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['nick'];
    $email = $_POST['email'];
    $pass1 = $_POST['pass1'];
    $pass2 = $_POST['pass2'];

    $wszystko_ok = true;

    if (strlen($username) < 3 || strlen($username) > 20) {
        $wszystko_ok = false;
        $_SESSION['e_nick'] = "Imię musi posiadać od 3 do 20 znaków";

    }

    if (ctype_alnum($username)==false){
        $wszystko_OK=false;
        $_SESSION['e_nick']="Nick może składać się z liter i cyfr (bez polskich znaków)";
    }
    if ($email == '') {
        $wszystko_ok = false;
        $_SESSION['e_email'] = "Potrzebujemy twojego e-maila";
    }

    if (strlen($pass1) < 3 || strlen($pass1) > 20) {
        $wszystko_ok = false;
        $_SESSION['e_pass'] = "Hasło musi posiadać od 3 do 20 znaków";
    }

    if ($pass1 != $pass2){
        $wszystko_ok = false;
        $_SESSION['e_pass'] = "Hasła nie są identyczne";
    }

    if (!isset($_POST['regulamin'])) {
        $wszystko_ok = false;
        $_SESSION['e_regulamin'] = "Zaakceptuj regulamin";
    }

    require_once 'connect.php';
    $conn = new mysqli($host, $db_user, $db_password, $db_name);

    if ($conn->connect_error) {
        die("Error: " . $conn->connect_error);
    }

    $check_username_sql = "SELECT * FROM users WHERE nick='$username'";
    $result = $conn->query($check_username_sql);
    if ($result->num_rows > 0) {
        $wszystko_ok = false;
        $_SESSION['e_pass'] = "Użytkownik o takiej nazwie już istnieje. Proszę wybrać inną nazwę.";
    }

    $hashed_password = password_hash($pass1, PASSWORD_DEFAULT);

    if ($wszystko_ok) {
        $sql = "INSERT INTO users VALUES(NULL, '$username', '$email', '$hashed_password', 'klient')";
        if ($conn->query($sql) === TRUE) {
            $_SESSION['succ_logowanie'] = "Dziękujemy za rejestracje!";
            header("Location: zaloguj.php"); 
                exit();
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } 

    // if (!isset($POST['regulamin'])){
    //     $wszystko_OK=false;
    //     $_SESSION['e_regulamin']="Zaakceptuj regulamin";
    // }

    // $sekret="6Le684UpAAAAAJ0a-wy9V-zjfQ1F98S5ycsp8JbW";
    // $sprawdz=file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$sekret.'$response='.$_POST['g-recaptcha-response']);

    // $odpowiedz=json_decode($sprawdz);

    // if($odpowiedz->success==false){
    //     $wszystko_OK=false;
    //     $_SESSION['e_bot']="Potwierdż , że nie jesteś botem";
    // }

    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/styleLogReg.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header id='headerPC'>
        <div id="logo"><img id="logoImg" src="https://th.bing.com/th/id/OIG3.uyOKU__TNibNU8s9VHJW?pid=ImgGn" > ITYevhen</div>
        <div id="menu"><a href="main.php">Główna</a><a href="uslugi.php">Usługi</a><a href="forum.php">Forum</a><a href="zaloguj.php"><div id="ZalogujLink">
            <?php
                if(isset($_SESSION['nick'])){
                    echo 'Kabinet';
                } else {
                    echo 'Zaloguj/Zarejestruj się';
                }
            ?>
        </div></a></div>
    </header>
    <header id='headerMob'>
        <img id='mobImg' src="img/menu-linie.png" onclick='showMenuMob()' alt="">
        <div id='menuMob'>
            <a href="main.php">Główna</a><br><br>
            <a href="uslugi.php">Usługi</a><br><br>
            <a href="forum.php">Forum</a><br><br>
            <a href="zaloguj.php">
                <?php
                    if(isset($_SESSION['nick'])){
                        echo 'Panel';
                    } else {
                        echo 'Zaloguj/Zarejestruj się';
                    }
                ?>
            </a>
        </div>
    </header>
    <form method="post" id="forma2">
        <h2>Zarejestruj się</h2>
        <div id="ludzik">
            <div class="eyes" id="eyes1"><div id="eyes21" class="eyes2"></div></div>
            <div class="eyes" id="eyes2"><div id="eyes22" class="eyes2"></div></div>
            <div id="usta"></div>
        </div>
        <input class="input" name="nick" type="text" placeholder="Imię" id="inpNick" oninput="Ludzik(this)">
        <?php   
            if(isset($_SESSION['e_nick'])){
                echo '<p class="error">'.$_SESSION['e_nick'].'<p><br>';
                unset($_SESSION['e_nick']);
            }
        ?>
        <input class="input" name="email" type="email" placeholder="Email" oninput="Ludzik(this)">
        <?php   
            if(isset($_SESSION['e_email'])){
                echo '<p class="error">'.$_SESSION['e_email'].'<p><br>';
                unset($_SESSION['e_email']);
            }
        ?>
        <input class="input" name="pass1" type="password" placeholder="Hasło" oninput="Ludzik2()">
        <input class="input" name="pass2" type="password" placeholder="Powtórz hasło" oninput="Ludzik2()">
        <?php   
            if(isset($_SESSION['e_pass'])){
                echo '<p class="error">'.$_SESSION['e_pass'].'<p><br>';
                unset($_SESSION['e_pass']);
            }
        ?>
        <div id='inpReg'><input class='inpReg' type="checkbox" name="regulamin" id="regulamin_checkbox"> <label class='inpReg' for="regulamin_checkbox">Akceptuję <a href="regulamin.php" id='regLink'>regulamin</a></label></div>
        <?php   
            if(isset($_SESSION['e_regulamin'])){
                echo '<p class="error">'.$_SESSION['e_regulamin'].'<p><br>';
                unset($_SESSION['e_regulamin']);
            }
        ?>
        <input class="input" type="submit" id="butt" style="margin-left: 25%;" value="Zarejestruj się">
    </form>
    
    <span style="margin-left: 49%;" id="linkRejestr">Masz już konto? <a href="zaloguj.php">Zaloguj się</a></span>
    <script src="script.js"></script>
</body>
</html>
