<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/styleMain.css">
</head>
<body>
    <header id='headerPC'>
        <div id="logo"><img id="logoImg" src="https://th.bing.com/th/id/OIG3.uyOKU__TNibNU8s9VHJW?pid=ImgGn" > ITYevhen</div>
        <div id="menu"><a href="main.php">Główna</a><a href="uslugi.php">Usługi</a><a href="forum.php">Forum</a><a href="zaloguj.php"><div id="ZalogujLink">
            <?php
                if(isset($_SESSION['nick'])){
                    echo 'Kabinet';
                } else {
                    echo 'Zaloguj/Zarejestruj się';
                }
            ?>
        </div></a></div>
    </header>
    <header>
        <img id='mobImg' src="img/menu-linie.png" onclick='showMenuMob()' alt="">
        <div id='menuMob'>
            <a href="main.php">Główna</a><br><br>
            <a href="uslugi.php">Usługi</a><br><br>
            <a href="forum.php">Forum</a><br><br>
            <a href="zaloguj.php">
                <?php
                    if(isset($_SESSION['nick'])){
                        echo 'Panel';
                    } else {
                        echo 'Zaloguj/Zarejestruj się';
                    }
                ?>
            </a>
        </div>
    </header>
    <script src="script.js"></script>
</body>
</html>