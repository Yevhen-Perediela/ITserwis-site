var l = 0
function like(el){
    l++
    if(l==2){
        el.src = 'img/like1.png'
        l=0
    }
    if(l==1){
        el.src = 'img/like2.png' 
        
    }
    
}

// document.addEventListener("DOMContentLoaded", function() {
//     var commentButtons = document.querySelectorAll(".comm-but");

//     commentButtons.forEach(function(button) {
//         button.addEventListener("click", function() {
//             var post = button.closest(".post");
//             var comments = post.querySelectorAll(".comment");
//             for (let com = 0; com < comments.length; com++) {
//                 if (comments[com].style.display === "none") {
//                     comments[com].style.display = "block";
//                     comments[com].style.animation = "marginRight 1s ease forwards"
//                 } else {
//                     comments[com].style.animation = "marginRightClose 1s ease forwards"
                    
//                     setTimeout(()=>{
//                         comments[com].style.display = "none";
//                     }, 1000)
                    
                    
//                 }
//             }
            
//         });
//     });
// });
function ShowComm(el) {
    var post = el.closest(".post");
    var comments = post.querySelectorAll(".comment");
    for (let com = 0; com < comments.length; com++) {
        if (comments[com].style.display === "none") {
            comments[com].style.display = "block";
            comments[com].style.animation = "marginRight 1s ease forwards"
        } else {
            comments[com].style.animation = "marginRightClose 1s ease forwards"
            
            setTimeout(()=>{
                comments[com].style.display = "none";
            }, 1000)
            
            
        }
    }
            
}



    document.getElementById('loadFile').addEventListener('change', function(event) {
        var file = event.target.files[0]; // Отримати перший вибраний файл
    
        if (file && file instanceof Blob) { // Перевірити, чи файл є об'єктом Blob
            var reader = new FileReader(); // Створити об'єкт FileReader
            reader.readAsDataURL(file); // Зчитати файл як URL-адресу даних
            reader.onload = function(e) {
                var imageUrl = e.target.result; // Отримати URL-адресу зображення з FileReader
    
                var container = document.getElementById('contImg'); // Виправлено ідентифікатор
                container.style.display = 'block'
                container.style.backgroundImage = "url('" + imageUrl + "')"; // Встановити фонове зображення контейнера
                container.style.backgroundSize = 'cover'; // Задати розмір фонового зображення
                container.style.backgroundPosition = 'center'; // Задати позицію фонового зображення
            };
        }
    });
    
    
function npForm(){
    var npForm = document.getElementById('npForm').style
    npForm.display = 'block'
    npForm.animation = 'npForm 0.7s ease forwards'
}
function npFormClose(){
    var npForm = document.getElementById('npForm').style
    npForm.animation = 'npFormClose 0.7s ease forwards'
    setTimeout(()=>{
        npForm.display = 'none'
    },600)   
}
   
    
    