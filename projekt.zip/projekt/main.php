<?php
    session_start()
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/styleMain.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Reddit+Mono:wght@200..900&family=Tilt+Neon&display=swap" rel="stylesheet">
  <title>Document</title>
</head>
<body>
<header id='headerPC'>
        <div id="logo"><img id="logoImg" src="https://th.bing.com/th/id/OIG3.uyOKU__TNibNU8s9VHJW?pid=ImgGn" > ITYevhen</div>
        <div id="menu"><a href="main.php">Główna</a><a href="uslugi.php">Usługi</a><a href="forum.php">Forum</a><a href="zaloguj.php"><div id="ZalogujLink">
            <?php
                if(isset($_SESSION['nick'])){
                    echo 'Panel';
                } else {
                    echo 'Zaloguj/Zarejestruj się';
                }
            ?>
        </div></a></div>
    </header>
    <header>
        <img id='mobImg' src="img/menu-linie.png" onclick='showMenuMob()' alt="">
        <div id='menuMob'>
            <a href="main.php">Główna</a><br><br>
            <a href="uslugi.php">Usługi</a><br><br>
            <a href="forum.php">Forum</a><br><br>
            <a href="zaloguj.php">
                <?php
                    if(isset($_SESSION['nick'])){
                        echo 'Panel';
                    } else {
                        echo 'Zaloguj/Zarejestruj się';
                    }
                ?>
            </a>
        </div>
    </header>
  <!-- <div id="questions" onmouseover="faq(1)" onmouseout="faq(0)" onclick="faq(2)">
      <img src="img/faq.png">
  </div> -->
  <div id="paralax">
    <span class="paralaxObj" id="paralax1">Naprawa</span>
    <span class="paralaxObj" id="paralax2">Obsługa</span>
    <span class="paralaxObj" id="paralax3">Instalacja</span>
    <span class="paralaxObj" id="paralax4">Pomoc techniczna</span>
    <span class="paralaxObj" id="paralax5">Konsultacje</span>
    <span class="paralaxObj" id="paralax6">Monitorowanie</span>
    <span class="paralaxObj" id="paralax7">Konfiguracja</span>
    <span class="paralaxObj" id="paralax8">Zabiezpeczenie</span>
    <img id="div1Img" src="https://cdn3d.iconscout.com/3d/premium/thumb/laptop-3825091-3202848.png?f=webp">
  </div>
  <div id="main">
    <div class="mainDivs" class="divDlaWyrownania" id="mainDiv1">
      <h3>Tworzymy Strony Internetowe</h3><br>
      <img class="mainPhoto" src="https://th.bing.com/th/id/OIG3.0J6wZ0ekggL0Rx.aQjzB?w=1024&h=1024&rs=1&pid=ImgDetMain" alt="">
      <span id="spanMain1">Zajmujemy się tworzeniem nowoczesnych i funkcjonalnych <b>stron internetowych</b> dla różnych branż i potrzeb. Nasze rozwiązania są dostosowane do Waszych celów biznesowych i najnowszych trendów technologicznych. <b>Skontaktuj się z nami</b>, abyśmy mogli stworzyć dla Ciebie wyjątkową  stronę internetową, która przyciągnie uwagę Twoich klientów.</span>
      <a href="uslugi.php"><button class="butt3">Skontaktuj się z nami</button></a>
    </div>
    <div class="mainDivs" id="mainDiv2">
      <h3>Naprawiamy twój sprzęt</h3>
      <img class="mainPhoto" id="photo2" src="https://th.bing.com/th/id/OIG4.iGfs294p5Np3.o8ay1oK?w=1024&h=1024&rs=1&pid=ImgDetMain" alt="">
      <span  id="spanMain2">W ITSerwis nie tylko tworzymy strony internetowe, ale również oferujemy usługi naprawy i konserwacji sprzętu komputerowego. Niezależnie od tego, czy potrzebujesz szybkiej naprawy laptopa, konserwacji komputera stacjonarnego czy też diagnozy problemu z urządzeniem mobilnym, nasi doświadczeni technicy są gotowi pomóc. Dzięki naszemu zaangażowaniu i fachowej wiedzy, możesz mieć pewność, że Twój sprzęt będzie w najlepszych rękach. Skontaktuj się z nami, abyśmy mogli szybko i sprawnie rozwiązać wszelkie problemy związane z Twoim sprzętem komputerowym.</span>
      <a href="uslugi.php"><button id="butt2">Skontaktuj się online</button></a>
    </div>
    <div class="mainDivs" id="mainDiv3" class="divDlaWyrownania">
      <h3>Konfigurujemy Serwery</h3><br>
      <img class="mainPhoto" id='photo3' src="https://th.bing.com/th/id/OIG3.UYVNvRmT2K87jnbWH2dl?w=1024&h=1024&rs=1&pid=ImgDetMain" alt="">
      <span  id="spanMain3">W ITSerwis zajmujemy się profesjonalną konfiguracją serwerów, dostosowaną do Twoich potrzeb. Dzięki naszemu doświadczeniu zapewniamy stabilność, wydajność i bezpieczeństwo Twojego serwera. Skontaktuj się z nami, abyśmy mogli omówić Twoje wymagania i zaproponować najlepsze rozwiązanie.</span>
      <a href="uslugi.php"><button class="butt1" >Napisz do nas</button></a>
    </div>
  </div>
  <footer>
    <div id="docAndReg"><a href="documentacja_projektu.docx">Documentacja</a> | <a href="regulamin.php">Regulamin</a></div>
    <p id='zrodla'>icons from Freepik | photos from chatBing</p>
    <p id="prawa">Wszelkie prawa zastrzeżone &copy; 2024 Autor: Yevhen</p>
  </footer>
  <script src="script.js"></script>
</body>
</html>