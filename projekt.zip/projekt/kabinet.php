<?php
    session_start();
    if(!isset($_SESSION['nick'])) {
        header("Location: zaloguj.php"); 
        exit();
    }else if($_SESSION['status_user'] == 'pracownik'){
        header("Location: pracownik.php"); 
        exit();
    }else if($_SESSION['status_user'] == 'admin'){
        header("Location: admin.php"); 
        exit();
    }
    require_once 'connect.php';   
    $conn = new mysqli($host, $db_user, $db_password, $db_name);
    
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $username = $_POST['changeNick'];
        $pass = $_POST['changePass'];
        $pass2 = $_POST['changePass2'];
        $id = $_SESSION['id'];
    
        $wszystko_ok_nick = true;
        $wszystko_ok_pass = true;
        if ($username != "" and (strlen($username) < 3 || strlen($username) > 20)) {
            $wszystko_ok_nick = false;
            $_SESSION['e_nick'] = "Imię musi posiadać od 3 do 20 znaków";
        }
    
        if ($pass != "" and (strlen($pass) < 3 || strlen($pass) > 20)) {
            $wszystko_ok_pass = false;
            $_SESSION['e_pass'] = "Hasło musi posiadać od 3 do 20 znaków";
        }

        if($pass != $pass2){
            $wszystko_ok_pass = false;
            $_SESSION['e_pass'] = "Hasła są nie identyczne";
        }

        $check_username_sql = "SELECT * FROM users WHERE nick='$username'";
        $result = $conn->query($check_username_sql);
        if ($result->num_rows > 0) {
            $wszystko_ok_nick = false;
            
        }
        $hashed_password = password_hash($pass, PASSWORD_DEFAULT);

        if ($username != "" and $wszystko_ok_nick) {
            $sql_nick = "UPDATE users SET nick='$username' WHERE id_user='$id'";
            if ($conn->query($sql_nick) === TRUE) {
                $_SESSION['nick'] = $username;
            } else {
                echo "Помилка: " . $sql_nick . "<br>" . $conn->error;
            }
        } 
        if ($pass != "" and $wszystko_ok_pass) {
            $sql_pass = "UPDATE users SET password='$hashed_password' WHERE id_user='$id'";
            if ($conn->query($sql_pass) === TRUE) {
            } else {
                echo "Помилка: " . $sql_pass . "<br>" . $conn->error;
            }
        } 
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/styleKab.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header id='headerPC'>
        <div id="logo"><img id="logoImg" src="https://th.bing.com/th/id/OIG3.uyOKU__TNibNU8s9VHJW?pid=ImgGn" > ITYevhen</div>
        <div id="menu"><a href="main.php">Główna</a><a href="uslugi.php">Usługi</a><a href="forum.php">Forum</a><a href="zaloguj.php"><div id="ZalogujLink">
            <?php
                if(isset($_SESSION['nick'])){
                    echo 'Panel';
                } else {
                    echo 'Zaloguj/Zarejestruj się';
                }
            ?>
        </div></a></div>
    </header>
    <header id='headerMob'>
        <img id='mobImg' src="img/menu-linie.png" onclick='showMenuMob()' alt="">
        <div id='menuMob'>
            <a href="main.php">Główna</a><br><br>
            <a href="uslugi.php">Usługi</a><br><br>
            <a href="forum.php">Forum</a><br><br>
            <a href="zaloguj.php">
                <?php
                    if(isset($_SESSION['nick'])){
                        echo 'Panel';
                    } else {
                        echo 'Zaloguj/Zarejestruj się';
                    }
                ?>
            </a>
        </div>
    </header>
    <div id="kabinetMain">
        
        <form action="logout.php" method="post" id="wylogujForm">
            <button id="wyloguj" type="submit">Wyloguj się</button>
        </form><br><br>
        <a href="gra.php"><button id="graButt">Gra</button></a>
        <img id='kabImg' src="https://img.freepik.com/free-psd/3d-illustration-person-with-sunglasses_23-2149436188.jpg?size=338&ext=jpg&ga=GA1.1.1700460183.1713052800&semt=sph" alt="">
        <p id="imie"><?php echo $_SESSION['nick']?></p>
        <hr>
        <form method="post">
            <h3>Zmień imie lub hasło:</h3><br>
            <input class='inpPanel' type="text" name="changeNick" placeholder="Wpisz nowe imie..."><br>
            <?php   
            if(isset($_SESSION['e_nick'])){
                echo '<p class="error">'.$_SESSION['e_nick'].'<p>';
                unset($_SESSION['e_nick']);
            }
            ?><br>
            <input class='inpPanel' type="password" name="changePass" placeholder="Wpisz nowe hasło..."><br><br>
            <input class='inpPanel' type="password" name="changePass2" placeholder="Powtórz hasło...">
            <?php   
            if(isset($_SESSION['e_pass'])){
                echo '<p class="error">'.$_SESSION['e_pass'].'<p>';
                unset($_SESSION['e_pass']);
            }
            ?><br><br>
            <button id="wyloguj" type="submit" style="float:right;">Zmień</button><br>
        </form>
        <hr>
        <h3>Twoje zamówienia:</h3><br>
        <ul>
        <?php   
            $showZam_sql = "SELECT * FROM zamowienia WHERE id_user='{$_SESSION['id']}'";
            $showZam = $conn->query($showZam_sql);
            if($showZam->num_rows > 0){

                while($row = $showZam->fetch_assoc()) {
                    
                    $typZam = $row['typ_zam'];
                    $kat1 = $row['kategoria1'];
                    $kat2 = $row['kategoria2'];
                    $kat3 = $row['kategoria3'];
                    $status = $row['status_zam'];
                    
                    // dla css / status
                    if($status == 'W trakcie' ){
                        $class = 'statusWtrakcie';
                    } else if($status == 'Prawie gotowe'){
                        $class = 'statusPrawie';
                    } else {
                        $class = 'statusGotowe';
                    }
                    if($typZam == 'naprawa'){
                        echo "<li>Naprawa urządzenia: <span class='spanFromDB'>".$kat1."</span>, nie działa <span class='spanFromDB'>".$kat2."</span> <span class=".$class.">".$status."</span></li> <br>";
                    } else if($typZam == 'serwer'){
                        echo "<li>Konfiguracja serwera. Wymagania: <span class='spanFromDB'>OS</span>: ".$kat1.", <span class='spanFromDB'>RAM: </span>".$kat2."GB, <span class='spanFromDB'>Storage: </span>".$kat3."TB <span class=".$class.">".$status."</span></li> <br>";
                    } else if($typZam == 'strony WWW'){
                        echo "<li>Strona internetowa. Wymagania: <span class='spanFromDB'>Typ</span>: ".$kat1.", <span class='spanFromDB'>Bezpeczeństwo: </span>".$kat2."<br><br> <span class=".$class.">".$status."</span></li> <br><br>";
                    } 
                    
                }
            } else {
                echo "Brak | <a href='uslugi.php'>Nasze usługi</a>";
            }
            $conn->close();  
        ?>
        </ul> 
    </div> 
    <script src="script.js"></script>
</body>
</html>