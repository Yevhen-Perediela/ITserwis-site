var strzalki = document.getElementsByClassName('strzalka')
var uslugi = document.getElementsByClassName('uslugi')
var uslugiDiv = document.getElementsByClassName('uslugiDiv')
var text1 = ''
var text2 = ''
var text0 = ''
var wynikCena = 0
for(var q=0;q<uslugi.length;q++){
    uslugi[q].style.height = '50px'
}
var radio = document.getElementsByClassName('radio')
var img = document.getElementsByClassName('el')
var wynikNap = document.getElementById('wynikNap')
function more(n){
    if(uslugi[n].style.height === '50px'){
        strzalki[n].style.rotate = '90deg'
        uslugi[n].style.height = '300px'
        if(screen.width < 427){
            uslugi[n].style.height = '400px'
        }
        if(n==1){
            text1 = '<div class="tekstUsl"><br><span class="spanUsl">Typ urządzenia:</span><br><div id="imgs" ><img class="el" src="img/computer.png" onclick="UslugaSprzet(0, 200)"><img class="el" src="img/laptop.png" onclick="UslugaSprzet(1, 300)"><img class="el" src="img/smartphone.png" onclick="UslugaSprzet(2, 150)"></div><br><span class="spanUsl">Co nie działa:</span><br><br><div id="niedziala2"><span class="el" onclick="UslugaSprzet(3, 100)">Bateria</span><span class="el" onclick="UslugaSprzet(4, 150)">Ekran</span><span class="el" onclick="UslugaSprzet(5, 50)">Klawiatura</span><span class="el" onclick="UslugaSprzet(6, 120)">Kamera</span><span class="el" onclick="PokazInp()" onclick="UslugaSprzet(7, 120)">Nie wiadomo/inne</span><input type="input" name="niedziala" id="inputInne" placeholder="Wpisz problem"></div><input type="submit" id="wynikButt2" class="wynikButt" value="Wyślij"><br><input type="radio" name="urzadzenie" value="komputer" class="radio"><input type="radio" name="urzadzenie" value="laptop" class="radio"><input type="radio" name="urzadzenie" value="telefon" class="radio"> <input type="radio" name="niedziala" class="radio" value="bateria"><input type="radio" name="niedziala" class="radio" value="ekran"><input type="radio" name="niedziala" class="radio" value="klawiatura"><input type="radio" name="niedziala" class="radio" value="kamera"><input type="radio" name="niedziala" class="radio" value="nie wiadomo/inne"></div> '
            setTimeout(()=>{
                uslugiDiv[n].innerHTML = text1
            },700)
            if(screen.width < 427){
                uslugi[n].style.height = '470px'
            }
            if(screen.width <= 768 && screen.width > 429){
                uslugi[n].style.height = '400px'
            }
        }else if(n==0){
            text0 = '<div class="tekstUsl"><br><span class="spanUsl">Typ strony:</span><br><br><div  id="niedziala"><span class="el" onclick="UslugaSprzet(0, 100)">CV</span><span class="el" onclick="UslugaSprzet(1, 100)">Aplikacja internetowa</span><span class="el" onclick="UslugaSprzet(2, 100)">Inne</span></div><br><br><span class="spanUsl">Bezpieczeństwo:</span><br><br><div id="niedziala"><span class="el" onclick="UslugaSprzet(3, 100)">Podstawowe</span><span class="el" onclick="UslugaSprzet(4, 100)">Zaawansowane</span></div><br><br><span class="spanUsl">Szablon strony:</span><br><br><input type="file" name="szablon"> <input type="submit" class="wynikButt" value="Wyślij"><br><input type="radio" name="typStrony" value="CV" class="radio"><input type="radio" name="typStrony" value="aplikacja-WWW" class="radio"><input type="radio" name="typStrony" value="inne" class="radio"> <input type="radio" name="Bezpeczenstwo" class="radio" value="podstawowe"><input type="radio" name="Bezpeczenstwo" class="radio" value="zaawansowane"></div>'
            setTimeout(()=>{
                uslugiDiv[n].innerHTML = text0
            },700)
           
        }else if(n==2){
            text2 ='<div class="tekstUsl"><br><span class="spanUsl">System operacyjny:</span><br><div id="imgs"><img src="img/linux.png" onclick="UslugaSprzet(0, 400)" class="el"><img style="padding: 0px; width: 100px;" id="windowsImg" src="img/windows.jpg" onclick="UslugaSprzet(1, 450)" class="el"></div><br><span class="spanUsl">RAM:</span><br><br><div id="niedziala"><span  onclick="UslugaSprzet(2, 100)" class="el">16 GB</span><span onclick="UslugaSprzet(3, 200)" class="el">32 Gb</span><span onclick="UslugaSprzet(4, 350)" class="el">64 GB</span></div><br><br><span class="spanUsl" class="el">HDD/SSD:</span><br><br><div id="niedziala"><span  onclick="UslugaSprzet(5, 150)" class="el">512 GB</span><span onclick="UslugaSprzet(6, 500)" class="el">1 TB</span><span onclick="UslugaSprzet(7, 700)" class="el">2 TB</span></div><input type="submit" class="wynikButt" value="Wyślij"><br><input type="radio" name="os" class="radio" value="linux"><input type="radio" name="os" class="radio" value="windows server"><input type="radio" name="ram" class="radio" value="16"><input type="radio" name="ram" class="radio" value="32"><input type="radio" name="ram" class="radio" value="64"><input type="radio" name="storage" class="radio" value="512"><input type="radio" name="storage" class="radio" value="1"><input type="radio" name="storage" class="radio" value="2"></div>'
            uslugi[n].style.height = '400px'
            setTimeout(()=>{
                uslugiDiv[n].innerHTML = text2
            },700)
            if(screen.width < 427){
                uslugi[n].style.height = '450px'
            }
        }  
    } else {
        uslugi[n].style.height = '50px'
        strzalki[n].style.rotate = '270deg'
        uslugiDiv[n].innerHTML = ''
    }
    for (let m = 0; m < 3; m++) {
        if(uslugi[m].style.height != '50px' && m != n){
            uslugiDiv[m].innerHTML = ''
            uslugi[m].style.height = '50px'
        }
        if(uslugi[m].style.height === '50px' && m != n){
            strzalki[m].style.rotate = '270deg'
            
        }
    } 
}


function PokazInp(){
    var inpInne = document.getElementById('inputInne')
    // inpInne.style.display = 'block'
    if(inpInne.style.display = 'none'){
        inpInne.style.display = 'block'
    } else{
        inpInne.style.display = 'none'
    }
}






function UslugaSprzet(n, cena){
    img[n].style.border = '6px double darkgreen'
    radio[n].checked = true
    for (let x = 0; x< radio.length; x++) {
        if(!radio[x].checked){
            img[x].style.border = '0px'
        }
    }
    
}


function submit(){
    document.getElementById('adminForm').submit()
}
function showMenuMob(){
var menuMob = document.getElementById('menuMob').style
var menuMobA = document.querySelectorAll('#menuMob a')
if(menuMob.display == 'none'){
  menuMob.display = 'block'
  menuMob.animation = 'menuMob 0.5s linear forwards'
  for (let i = 0; i < menuMobA.length; i++) {
    menuMobA[i].style.animation = 'menuMob 0.5s linear'
  }
} else {
  for (let i = 0; i < menuMobA.length; i++) {
    menuMobA[i].style.animation = 'menuMobClose 0.5s linear'
  }
  menuMob.animation = 'menuMobClose 0.5s linear'
  setTimeout(()=>{
    menuMob.display = 'none'
  }, 480)
  
}
}



/* <form method="post"><input type="radio" name="os" class="radio" value="linux"><input type="radio" name="os" class="radio" value="windows server"><input type="radio" name="ram" class="radio" value="16"><input type="radio" name="ram" class="radio" value="32"><input type="radio" name="ram" class="radio" value="64"><input type="radio" name="storage" class="radio" value="512"><input type="radio" name="storage" class="radio" value="1"><input type="radio" name="storage" class="radio" value="2"></input> */
/* <form method="post"><input type="radio" name="urzadzenie" value="komputer" class="radio"><input type="radio" name="urzadzenie" value="laptop" class="radio"><input type="radio" name="urzadzenie" value="telefon" class="radio"><input type="radio" name="niedziala" class="radio" value="bateria"><input type="radio" name="niedziala" class="radio" value="ekran"><input type="radio" name="niedziala" class="radio" value="klawiatura"> <input type="radio" name="niedziala" class="radio" value="kamera"> <input type="radio" name="niedziala" class="radio" value="nie wiadomo/inne"></input> */