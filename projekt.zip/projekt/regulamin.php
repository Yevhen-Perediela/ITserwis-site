<?php
    session_start()
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header id='headerPC'>
        <div id="logo"><img id="logoImg" src="https://th.bing.com/th/id/OIG3.uyOKU__TNibNU8s9VHJW?pid=ImgGn" > ITYevhen</div>
        <div id="menu"><a href="main.php">Główna</a><a href="uslugi.php">Usługi</a><a href="forum.php">Forum</a><a href="zaloguj.php"><div id="ZalogujLink">
            <?php
                if(isset($_SESSION['nick'])){
                    echo 'Panel';
                } else {
                    echo 'Zaloguj/Zarejestruj się';
                }
            ?>
        </div></a></div>
    </header>
    <header>
        <img id='mobImg' src="img/menu-linie.png" onclick='showMenuMob()' alt="">
        <div id='menuMob'>
            <a href="main.php">Główna</a><br><br>
            <a href="uslugi.php">Usługi</a><br><br>
            <a href="forum.php">Forum</a><br><br>
            <a href="zaloguj.php">
                <?php
                    if(isset($_SESSION['nick'])){
                        echo 'Panel';
                    } else {
                        echo 'Zaloguj/Zarejestruj się';
                    }
                ?>
            </a>
        </div>
    </header>
    <div id="regulamin">
        <button onclick='Color(1)'>Zmień kolor na green</button>
        <button onclick='Color(2)'>Zmień kolor na white</button><br><br>
        <h1 id="h1reg">Regulamin Serwisu IT</h1> <br><br>

        1. Warunki  <br>

        1.1. Niniejszy regulamin określa zasady korzystania z usług świadczonych przez nasz serwis IT. <br>

        1.2. Korzystając z naszych usług, zgadzasz się na postanowienia niniejszego regulaminu oraz wszelkie inne zasady i procedury określone na naszej stronie internetowej. <br>

        2. Usługi <br>

        2.1. Nasz serwis IT oferuje następujące usługi: <br>

        Tworzenie stron internetowych, <br>
        Naprawa sprzętu komputerowego, <br>
        Konfiguracja serwerów. <br>
        2.2. Szczegółowe informacje dotyczące poszczególnych usług dostępne są na naszej stronie internetowej oraz mogą być uzgodnione indywidualnie z naszymi klientami.<br>

        3. Zamówienia i płatności<br>

        3.1. Zamówienia na nasze usługi można składać za pośrednictwem formularza kontaktowego dostępnego na stronie internetowej lub poprzez bezpośredni kontakt telefoniczny lub e-mailowy.<br>

        3.2. Warunki płatności oraz ceny usług są uzgadniane indywidualnie z klientem i podawane w ofercie handlowej.<br>

        3.3. Opłaty za nasze usługi mogą być pobierane przed rozpoczęciem pracy lub po jej zakończeniu, w zależności od uzgodnień.<br>

        4. Gwarancja<br>

        4.1. Oferujemy gwarancję na wykonywane przez nas usługi, zgodnie z warunkami uzgodnionymi z klientem.<br>

        4.2. Warunki gwarancji oraz okres jej obowiązywania są określone indywidualnie dla każdej usługi.<br>

        5. Odpowiedzialność<br>

        5.1. Nasz serwis IT nie ponosi odpowiedzialności za szkody wynikłe z niewłaściwego korzystania z naszych usług przez klienta.<br>

        5.2. Nie ponosimy odpowiedzialności za ewentualne utraty danych klienta w trakcie wykonywania usług, chyba że wynikają one bezpośrednio z naszej winy.<br>

        6. Ochrona danych osobowych<br>

        6.1. Dbamy o ochronę danych osobowych naszych klientów zgodnie z obowiązującymi przepisami prawa oraz naszą polityką prywatności.<br>

        6.2. Dane osobowe klientów są wykorzystywane wyłącznie w celu realizacji zamówionych usług oraz mogą być przetwarzane w zakresie niezbędnym do prowadzenia działalności serwisu IT.<br>

        7. Postanowienia końcowe<br>

        7.1. Niniejszy regulamin może ulec zmianie w dowolnym czasie. Aktualna wersja regulaminu jest zawsze dostępna na naszej stronie internetowej.<br>

        7.2. Wszelkie spory wynikłe z niniejszego regulaminu będą rozstrzygane zgodnie z obowiązującym prawem polskim.<br>
    </div>
    <script src="script.js"></script>
</body>
</html>